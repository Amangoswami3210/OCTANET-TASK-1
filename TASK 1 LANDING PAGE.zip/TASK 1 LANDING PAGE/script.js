document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Thank you for signing up!');
});
